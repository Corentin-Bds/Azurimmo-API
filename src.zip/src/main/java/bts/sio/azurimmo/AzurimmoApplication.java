package bts.sio.azurimmo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AzurimmoApplication {

    public static void main(String[] args) {
        SpringApplication.run(AzurimmoApplication.class, args);
    }

}
