package bts.sio.azurimmo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AzurimmoApplicationTests {

    @Test
    void contextLoads() {
    }

}
